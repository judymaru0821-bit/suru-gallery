import { useState, useEffect, useRef } from "react";

// ─────────────────────────────────────────────────────────────────
// JSONBin.io — 免費雲端資料庫，不需要帳號設定，直接用
// 這裡用固定的 bin ID，所有人共用同一份資料
// ─────────────────────────────────────────────────────────────────
const JSONBIN_API = "https://api.jsonbin.io/v3";
const JSONBIN_KEY = "$2a$10$placeholder"; // 會在初始化時建立

// 用 localStorage 記住 bin ID（第一次使用時自動建立）
async function getBinId() {
  let binId = localStorage.getItem("suru_bin_id");
  if (binId) return binId;
  // 建立新的 bin
  const res = await fetch(`${JSONBIN_API}/b`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Bin-Name": "suru-gallery",
      "X-Bin-Private": "false"
    },
    body: JSON.stringify({ paintings: [], messages: [], visitors: 0 })
  });
  const data = await res.json();
  binId = data.metadata?.id;
  if (binId) localStorage.setItem("suru_bin_id", binId);
  return binId;
}

async function readData() {
  const binId = await getBinId();
  const res = await fetch(`${JSONBIN_API}/b/${binId}/latest`);
  const data = await res.json();
  return data.record || { paintings: [], messages: [], visitors: 0 };
}

async function writeData(record) {
  const binId = await getBinId();
  await fetch(`${JSONBIN_API}/b/${binId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(record)
  });
}

// ── AI 自動描述 ────────────────────────────────────────────────────
async function analyzeImage(base64, mediaType) {
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 200,
        messages: [{
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: mediaType, data: base64 } },
            { type: "text", text: "這是一幅色鉛筆畫。請用繁體中文，用溫暖詩意的文字寫一段約30字的畫作描述，只需要描述內容，不要任何前言後記。" }
          ]
        }]
      })
    });
    const data = await res.json();
    return data.content?.[0]?.text || "";
  } catch { return ""; }
}

function formatDate(str) {
  if (!str) return "";
  const d = new Date(str);
  if (isNaN(d)) return str;
  return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`;
}

const ADMIN_PW = "suRu2024";

// ══════════════════════════════════════════════════════════════════
export default function App() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [tab, setTab] = useState("gallery");
  const [selected, setSelected] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [showUpload, setShowUpload] = useState(false);
  const [adminPw, setAdminPw] = useState("");
  const [adminErr, setAdminErr] = useState("");

  const [form, setForm] = useState({ title: "", date: "", note: "", preview: "", base64: "", mediaType: "" });
  const [uploading, setUploading] = useState(false);
  const [autoDesc, setAutoDesc] = useState("");
  const [genDesc, setGenDesc] = useState(false);

  const [msgForm, setMsgForm] = useState({ name: "", text: "" });
  const [sendingMsg, setSendingMsg] = useState(false);

  const fileRef = useRef();

  // ── 載入資料 ───────────────────────────────────────────────────
  useEffect(() => {
    async function load() {
      try {
        const d = await readData();
        // 增加訪客數
        d.visitors = (d.visitors || 0) + 1;
        await writeData(d);
        setData(d);
      } catch (e) {
        setError("資料載入失敗，請重新整理頁面");
      }
      setLoading(false);
    }
    load();
  }, []);

  // ── 圖片選擇 ───────────────────────────────────────────────────
  async function onFileSelect(e) {
    const file = e.target.files[0];
    if (!file) return;

    // 壓縮圖片（避免資料太大）
    const compressed = await compressImage(file, 800);
    const base64 = compressed.split(",")[1];
    setForm(f => ({ ...f, preview: compressed, base64, mediaType: file.type }));

    setGenDesc(true);
    const desc = await analyzeImage(base64, file.type);
    setAutoDesc(desc);
    setGenDesc(false);
  }

  // 壓縮圖片
  function compressImage(file, maxSize) {
    return new Promise((resolve) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let w = img.width, h = img.height;
        if (w > maxSize || h > maxSize) {
          if (w > h) { h = Math.round(h * maxSize / w); w = maxSize; }
          else { w = Math.round(w * maxSize / h); h = maxSize; }
        }
        canvas.width = w; canvas.height = h;
        canvas.getContext("2d").drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/jpeg", 0.82));
        URL.revokeObjectURL(url);
      };
      img.src = url;
    });
  }

  // ── 上傳作品 ───────────────────────────────────────────────────
  async function handleUpload() {
    if (!form.base64 || !form.title) return;
    setUploading(true);
    try {
      const painting = {
        id: Date.now().toString(),
        title: form.title,
        date: form.date,
        note: form.note || autoDesc,
        imageData: `data:${form.mediaType};base64,${form.base64}`,
        createdAt: new Date().toISOString()
      };
      const updated = { ...data, paintings: [painting, ...data.paintings] };
      await writeData(updated);
      setData(updated);
      setForm({ title: "", date: "", note: "", preview: "", base64: "", mediaType: "" });
      setAutoDesc("");
      setShowUpload(false);
    } catch { alert("上傳失敗，請重試"); }
    setUploading(false);
  }

  // ── 刪除作品 ───────────────────────────────────────────────────
  async function handleDelete(id) {
    if (!window.confirm("確定要刪除這幅作品嗎？")) return;
    const updated = { ...data, paintings: data.paintings.filter(p => p.id !== id) };
    await writeData(updated);
    setData(updated);
    if (selected?.id === id) setSelected(null);
  }

  // ── 留言 ───────────────────────────────────────────────────────
  async function handleMsg() {
    if (!msgForm.name.trim() || !msgForm.text.trim()) return;
    setSendingMsg(true);
    try {
      const msg = {
        id: Date.now().toString(),
        name: msgForm.name.trim(),
        text: msgForm.text.trim(),
        createdAt: new Date().toISOString()
      };
      const updated = { ...data, messages: [msg, ...data.messages] };
      await writeData(updated);
      setData(updated);
      setMsgForm({ name: "", text: "" });
    } catch { alert("留言失敗，請重試"); }
    setSendingMsg(false);
  }

  async function handleDeleteMsg(id) {
    const updated = { ...data, messages: data.messages.filter(m => m.id !== id) };
    await writeData(updated);
    setData(updated);
  }

  // ── 管理員 ─────────────────────────────────────────────────────
  function doLogin() {
    if (adminPw === ADMIN_PW) {
      setIsAdmin(true); setShowLogin(false); setAdminErr(""); setAdminPw("");
    } else { setAdminErr("密碼錯誤"); }
  }

  // ══════════════════════════════════════════════════════════════
  if (loading) return (
    <div style={S.center}>
      <div style={{ fontSize: 48, animation: "spin 2s linear infinite" }}>🌸</div>
      <p style={{ fontFamily: FT, color: C.brown, fontSize: 18, marginTop: 16 }}>素如的畫廊 載入中…</p>
    </div>
  );

  if (error) return (
    <div style={S.center}>
      <p style={{ color: "#c0392b", fontSize: 16 }}>{error}</p>
    </div>
  );

  const paintings = data?.paintings || [];
  const messages = data?.messages || [];
  const visitors = data?.visitors || 0;

  return (
    <div style={S.root}>
      <div style={S.blob1} /><div style={S.blob2} />

      {/* Header */}
      <header style={S.header}>
        <div style={S.hInner}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: 22, color: C.sakuraDark }}>✿</span>
            <div>
              <h1 style={S.title}>素如的畫廊</h1>
              <p style={S.subtitle}>色鉛筆の世界へようこそ</p>
            </div>
            <span style={{ fontSize: 22, color: C.sakuraDark }}>✿</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={S.badge}>
              <span>👁</span>
              <strong style={{ color: C.brown }}>{visitors.toLocaleString()}</strong>
              <span style={{ fontSize: 12, color: C.muted }}>訪客</span>
            </div>
            {!isAdmin
              ? <button style={S.btn} onClick={() => setShowLogin(true)}>管理</button>
              : <button style={{ ...S.btn, background: C.sakuraDark, color: "#fff" }} onClick={() => setIsAdmin(false)}>登出</button>
            }
          </div>
        </div>
        <nav style={S.nav}>
          {[["gallery", "🎨 作品畫廊"], ["guestbook", "💌 訪客留言"]].map(([t, l]) => (
            <button key={t} style={t === tab ? S.navOn : S.navOff} onClick={() => setTab(t)}>{l}</button>
          ))}
        </nav>
      </header>

      {/* Main */}
      <main style={S.main}>

        {/* 畫廊 */}
        {tab === "gallery" && <>
          {isAdmin && (
            <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 28 }}>
              <button style={S.addBtn} onClick={() => setShowUpload(true)}>＋ 新增作品</button>
              <span style={{ color: C.muted, fontSize: 13 }}>共 {paintings.length} 幅作品</span>
            </div>
          )}
          {paintings.length === 0
            ? <div style={S.empty}><p style={{ fontSize: 56 }}>🎨</p><p style={{ color: C.muted, fontSize: 15, marginTop: 12 }}>畫廊準備中，敬請期待…</p></div>
            : <div style={S.grid}>
              {paintings.map((p, i) => (
                <div key={p.id} style={{ ...S.card, animationDelay: `${i * 0.06}s` }}
                  onMouseEnter={e => {
                    e.currentTarget.style.transform = "translateY(-6px)";
                    e.currentTarget.style.boxShadow = "0 12px 32px rgba(139,94,60,0.2)";
                    e.currentTarget.querySelector(".ov").style.opacity = "1";
                    e.currentTarget.querySelector("img").style.transform = "scale(1.06)";
                  }}
                  onMouseLeave={e => {
                    e.currentTarget.style.transform = "";
                    e.currentTarget.style.boxShadow = "0 2px 12px rgba(139,94,60,0.08)";
                    e.currentTarget.querySelector(".ov").style.opacity = "0";
                    e.currentTarget.querySelector("img").style.transform = "";
                  }}
                  onClick={() => setSelected(p)}>
                  <div style={S.imgWrap}>
                    <img src={p.imageData} alt={p.title} style={S.cardImg} />
                    <div className="ov" style={S.cardOv}>點擊欣賞</div>
                  </div>
                  <div style={{ padding: "14px 16px 16px" }}>
                    <p style={S.cardTitle}>{p.title}</p>
                    {p.date && <p style={S.cardDate}>{formatDate(p.date)}</p>}
                    {p.note && <p style={S.cardNote}>{p.note}</p>}
                  </div>
                </div>
              ))}
            </div>
          }
        </>}

        {/* 留言板 */}
        {tab === "guestbook" && (
          <div style={{ maxWidth: 680, margin: "0 auto" }}>
            <div style={{ textAlign: "center", marginBottom: 28 }}>
              <h2 style={{ fontFamily: FT, fontSize: 22, color: C.brown, margin: "0 0 8px" }}>訪客留言板</h2>
              <p style={{ color: C.muted, fontSize: 14 }}>留下你對畫作的感受，讓素如知道你來過 ✉️</p>
            </div>
            <div style={S.msgBox}>
              <input style={S.input} placeholder="你的名字" value={msgForm.name}
                onChange={e => setMsgForm(f => ({ ...f, name: e.target.value }))} />
              <textarea style={S.textarea} placeholder="留下你的話語…" rows={4} value={msgForm.text}
                onChange={e => setMsgForm(f => ({ ...f, text: e.target.value }))} />
              <button style={S.addBtn} onClick={handleMsg} disabled={sendingMsg}>
                {sendingMsg ? "傳送中…" : "送出留言 ✉️"}
              </button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {messages.length === 0
                ? <p style={{ color: C.muted, textAlign: "center", fontSize: 15 }}>還沒有留言，來做第一個吧！</p>
                : messages.map(m => (
                  <div key={m.id} style={S.msgCard}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                      <strong style={{ color: C.brown, fontSize: 15 }}>{m.name}</strong>
                      <span style={{ fontSize: 12, color: C.muted }}>{formatDate(m.createdAt)}</span>
                      {isAdmin && <button style={{ marginLeft: "auto", background: "none", border: "none", color: C.muted, cursor: "pointer" }} onClick={() => handleDeleteMsg(m.id)}>✕</button>}
                    </div>
                    <p style={{ fontSize: 14, color: C.text, lineHeight: 1.8, margin: 0 }}>{m.text}</p>
                  </div>
                ))
              }
            </div>
          </div>
        )}
      </main>

      {/* 燈箱 */}
      {selected && (
        <div style={S.overlay} onClick={() => setSelected(null)}>
          <div style={S.lb} onClick={e => e.stopPropagation()}>
            <button style={S.lbX} onClick={() => setSelected(null)}>✕</button>
            {isAdmin && <button style={S.lbDel} onClick={() => handleDelete(selected.id)}>刪除作品</button>}
            <img src={selected.imageData} alt={selected.title} style={S.lbImg} />
            <div style={{ padding: "20px 28px 28px" }}>
              <h2 style={{ fontFamily: FT, fontSize: 22, color: C.brown, margin: "0 0 8px" }}>{selected.title}</h2>
              {selected.date && <p style={{ fontSize: 14, color: C.muted, margin: "0 0 8px" }}>📅 {formatDate(selected.date)}</p>}
              {selected.note && <p style={{ fontSize: 15, color: C.text, lineHeight: 1.8, margin: 0 }}>{selected.note}</p>}
            </div>
          </div>
        </div>
      )}

      {/* 上傳 Modal */}
      {showUpload && (
        <div style={S.overlay} onClick={() => setShowUpload(false)}>
          <div style={S.modal} onClick={e => e.stopPropagation()}>
            <h2 style={S.modalT}>新增作品</h2>
            <div style={S.dropzone} onClick={() => fileRef.current.click()}>
              {form.preview
                ? <img src={form.preview} alt="" style={{ width: "100%", maxHeight: 260, objectFit: "contain" }} />
                : <div style={{ textAlign: "center", color: C.muted }}><div style={{ fontSize: 40 }}>🖼</div><p style={{ fontSize: 13, marginTop: 8 }}>點擊選擇圖片</p></div>
              }
            </div>
            <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={onFileSelect} />
            {genDesc && <p style={{ fontSize: 13, color: C.sakuraDark, margin: "8px 0" }}>✨ AI 正在感受這幅畫…</p>}
            {autoDesc && !genDesc && (
              <div style={{ background: C.paper, borderRadius: 10, padding: "12px 14px", marginBottom: 12, border: `1px solid ${C.border}` }}>
                <p style={{ fontSize: 12, color: C.sakuraDark, margin: "0 0 4px", fontWeight: 700 }}>✨ AI 畫作感受：</p>
                <p style={{ fontSize: 13, color: C.text, margin: 0, lineHeight: 1.7 }}>{autoDesc}</p>
              </div>
            )}
            <input style={S.input} placeholder="作品標題 *" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
            <input style={S.input} type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />
            <textarea style={S.textarea} placeholder="備註（可留空，將使用 AI 描述）" rows={3} value={form.note} onChange={e => setForm(f => ({ ...f, note: e.target.value }))} />
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 12, marginTop: 8 }}>
              <button style={S.cancelBtn} onClick={() => setShowUpload(false)}>取消</button>
              <button style={S.addBtn} onClick={handleUpload} disabled={uploading || !form.base64 || !form.title}>
                {uploading ? "上傳中…" : "新增作品"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 管理員登入 */}
      {showLogin && (
        <div style={S.overlay} onClick={() => setShowLogin(false)}>
          <div style={{ ...S.modal, maxWidth: 340 }} onClick={e => e.stopPropagation()}>
            <h2 style={S.modalT}>管理員登入</h2>
            <input style={S.input} type="password" placeholder="請輸入管理密碼"
              value={adminPw} onChange={e => setAdminPw(e.target.value)}
              onKeyDown={e => e.key === "Enter" && doLogin()} />
            {adminErr && <p style={{ color: "#c0392b", fontSize: 13, marginBottom: 8 }}>{adminErr}</p>}
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 12, marginTop: 12 }}>
              <button style={S.cancelBtn} onClick={() => setShowLogin(false)}>取消</button>
              <button style={S.addBtn} onClick={doLogin}>登入</button>
            </div>
          </div>
        </div>
      )}

      <footer style={{ textAlign: "center", padding: 24, borderTop: `1px solid ${C.border}`, color: C.muted, fontSize: 13, fontFamily: FT, letterSpacing: "0.05em", position: "relative", zIndex: 1 }}>
        素如的畫廊 · 以色鉛筆繪出溫柔的世界 ✿
      </footer>
    </div>
  );
}

// ── 色彩 & 樣式 ───────────────────────────────────────────────────
const C = {
  cream: "#fdf6ee", paper: "#faf0e4", sakura: "#f2c4b8",
  sakuraDark: "#d9846e", peach: "#f4a27a", tan: "#e8c9a0",
  brown: "#8b5e3c", text: "#4a3728", muted: "#8c6e5a",
  border: "#e8d5bc", white: "#fffdf9",
};
const FT = "'Noto Serif TC', serif";
const FB = "'Noto Sans TC', sans-serif";
const GRAD = `linear-gradient(135deg, ${C.peach}, ${C.sakuraDark})`;

const S = {
  root: { minHeight: "100vh", background: C.cream, fontFamily: FB, color: C.text, position: "relative", overflowX: "hidden" },
  blob1: { position: "fixed", top: -120, right: -120, width: 400, height: 400, borderRadius: "50%", background: `radial-gradient(circle, ${C.sakura}55 0%, transparent 70%)`, pointerEvents: "none", zIndex: 0 },
  blob2: { position: "fixed", bottom: -100, left: -100, width: 350, height: 350, borderRadius: "50%", background: `radial-gradient(circle, ${C.tan}66 0%, transparent 70%)`, pointerEvents: "none", zIndex: 0 },
  center: { height: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: C.cream },
  header: { background: `linear-gradient(135deg, ${C.white}, ${C.paper})`, borderBottom: `2px solid ${C.border}`, position: "sticky", top: 0, zIndex: 100, boxShadow: "0 2px 16px rgba(139,94,60,0.1)" },
  hInner: { maxWidth: 1100, margin: "0 auto", padding: "16px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 },
  title: { fontFamily: FT, fontSize: 28, fontWeight: 700, color: C.brown, margin: 0, letterSpacing: "0.1em" },
  subtitle: { fontSize: 13, color: C.muted, margin: 0, letterSpacing: "0.15em" },
  badge: { display: "flex", alignItems: "center", gap: 6, background: C.paper, border: `1px solid ${C.border}`, borderRadius: 20, padding: "6px 14px", fontSize: 14 },
  btn: { padding: "6px 16px", borderRadius: 20, border: `1px solid ${C.border}`, background: C.white, color: C.muted, fontSize: 13, cursor: "pointer" },
  nav: { maxWidth: 1100, margin: "0 auto", padding: "0 24px", display: "flex", gap: 4 },
  navOff: { padding: "10px 24px", fontSize: 14, background: "transparent", border: "none", borderBottom: "3px solid transparent", color: C.muted, cursor: "pointer", fontFamily: FB },
  navOn: { padding: "10px 24px", fontSize: 14, background: "transparent", border: "none", borderBottom: `3px solid ${C.sakuraDark}`, color: C.brown, cursor: "pointer", fontWeight: 700, fontFamily: FB },
  main: { maxWidth: 1100, margin: "0 auto", padding: "32px 24px 80px", position: "relative", zIndex: 1 },
  addBtn: { padding: "10px 24px", borderRadius: 24, background: GRAD, color: "#fff", border: "none", fontSize: 15, cursor: "pointer", fontFamily: FB, boxShadow: `0 4px 12px ${C.sakura}99` },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 24 },
  card: { background: C.white, border: `1px solid ${C.border}`, borderRadius: 16, overflow: "hidden", cursor: "pointer", transition: "transform 0.25s, box-shadow 0.25s", boxShadow: "0 2px 12px rgba(139,94,60,0.08)", animation: "fadeUp 0.5s both" },
  imgWrap: { position: "relative", overflow: "hidden", paddingBottom: "75%" },
  cardImg: { position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", transition: "transform 0.4s" },
  cardOv: { position: "absolute", inset: 0, background: "rgba(74,55,40,0.55)", display: "flex", alignItems: "center", justifyContent: "center", opacity: 0, transition: "opacity 0.3s", color: "#fff", fontSize: 14, letterSpacing: "0.1em" },
  cardTitle: { fontFamily: FT, fontSize: 16, fontWeight: 700, color: C.brown, margin: "0 0 4px" },
  cardDate: { fontSize: 12, color: C.muted, margin: "0 0 4px" },
  cardNote: { fontSize: 13, color: C.text, margin: 0, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden", lineHeight: 1.6 },
  empty: { textAlign: "center", padding: "80px 0" },
  overlay: { position: "fixed", inset: 0, background: "rgba(30,20,10,0.8)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 },
  lb: { background: C.white, borderRadius: 20, maxWidth: 760, width: "100%", maxHeight: "90vh", overflow: "auto", position: "relative", boxShadow: "0 20px 60px rgba(0,0,0,0.4)" },
  lbX: { position: "absolute", top: 14, right: 14, background: C.paper, border: `1px solid ${C.border}`, borderRadius: "50%", width: 34, height: 34, cursor: "pointer", fontSize: 16, zIndex: 10, color: C.brown },
  lbDel: { position: "absolute", top: 14, left: 14, background: "#c0392b", border: "none", borderRadius: 20, padding: "6px 14px", color: "#fff", fontSize: 13, cursor: "pointer", zIndex: 10 },
  lbImg: { width: "100%", display: "block", borderRadius: "20px 20px 0 0", maxHeight: 520, objectFit: "contain", background: C.paper },
  modal: { background: C.white, borderRadius: 20, maxWidth: 520, width: "100%", maxHeight: "90vh", overflow: "auto", padding: 32, boxShadow: "0 20px 60px rgba(0,0,0,0.3)" },
  modalT: { fontFamily: FT, fontSize: 20, color: C.brown, margin: "0 0 20px" },
  dropzone: { border: `2px dashed ${C.border}`, borderRadius: 12, minHeight: 180, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", marginBottom: 16, background: C.paper },
  input: { width: "100%", padding: "10px 14px", marginBottom: 12, borderRadius: 10, border: `1px solid ${C.border}`, fontSize: 14, fontFamily: FB, color: C.text, background: C.paper, display: "block", outline: "none" },
  textarea: { width: "100%", padding: "10px 14px", marginBottom: 12, borderRadius: 10, border: `1px solid ${C.border}`, fontSize: 14, fontFamily: FB, color: C.text, background: C.paper, resize: "vertical", display: "block", outline: "none" },
  cancelBtn: { padding: "10px 22px", borderRadius: 20, border: `1px solid ${C.border}`, background: C.white, color: C.muted, cursor: "pointer", fontSize: 14 },
  msgBox: { background: C.white, border: `1px solid ${C.border}`, borderRadius: 16, padding: 24, marginBottom: 28 },
  msgCard: { background: C.white, border: `1px solid ${C.border}`, borderRadius: 14, padding: "16px 20px", boxShadow: "0 2px 8px rgba(139,94,60,0.06)" },
};

const styleEl = document.createElement("style");
styleEl.textContent = `
  @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  @keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
`;
if (!document.getElementById("sg")) { styleEl.id = "sg"; document.head.appendChild(styleEl); }
